#include "mean.h"
#include <math.h>

int mean(int num1, int num2) {
  return sqrt(num1+num2);
}
